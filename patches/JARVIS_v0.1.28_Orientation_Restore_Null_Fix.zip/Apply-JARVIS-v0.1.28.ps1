$ErrorActionPreference = 'Stop'

$patchRoot = $PSScriptRoot
$projectRoot = [System.IO.Path]::GetFullPath((Join-Path $patchRoot '..\..'))
$overlayRoot = Join-Path $patchRoot 'JARVIS'

if ((Split-Path -Leaf $projectRoot) -ne 'JARVIS') {
    throw "Extract this patch under F:\JARVIS\patches\v0.1.28. Resolved project root: $projectRoot"
}

$relative = 'frontend\src\App.tsx'
$source = Join-Path $overlayRoot $relative
$destination = Join-Path $projectRoot $relative
if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Patch source is missing: $source" }
if (-not (Test-Path -LiteralPath $destination -PathType Leaf)) { throw "JARVIS target file is missing: $destination" }

$sourceText = [System.IO.File]::ReadAllText($source)
$required = @(
    'function normalizeOrientation(value: unknown): VisualOrientation | undefined',
    'orientation: normalizeOrientation(message.orientation)',
    "reference: null, image_prompt: '', poster: false, design_variant: undefined, orientation: normalizeOrientation(message.orientation)",
    'reference: undefined, orientation: normalizeOrientation(message.orientation)'
)
foreach ($needle in $required) {
    if (-not $sourceText.Contains($needle)) { throw "Patch validation failed. Required source expression missing: $needle" }
}

$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupRoot = Join-Path $projectRoot "backups\pre-v0.1.28-$timestamp"
$backupFile = Join-Path $backupRoot $relative
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $backupFile) | Out-Null
Copy-Item -LiteralPath $destination -Destination $backupFile -Force
Copy-Item -LiteralPath $source -Destination $destination -Force

Write-Host ''
Write-Host 'J.A.R.V.I.S. v0.1.28 orientation restore fix applied.' -ForegroundColor Green
Write-Host "File replaced: $relative"
Write-Host "Backup: $backupRoot"
Write-Host 'No package files, dependencies, models, environments, or configuration were modified.' -ForegroundColor Cyan
