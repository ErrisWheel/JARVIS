J.A.R.V.I.S. v0.1.28 — Restored Conversation Orientation Null Fix

Fixes the remaining TypeScript build error in frontend/src/App.tsx.

Root cause:
The v0.1.27 patch normalized orientation only on messages that had a generated-image reference. Messages without a reference returned the raw API message, whose orientation type allows null. The restored conversation array therefore still contained orientation: null and could not be assigned to ChatLine[].

Fix:
Normalize orientation in BOTH no-reference branches:
- While decorating messages returned by the conversation API.
- While building the restored ChatLine array.

Only 'portrait' and 'landscape' are retained. Null or unsupported values become undefined.

Installation:
1. Stop both JARVIS terminals with Ctrl+C.
2. Save this ZIP to F:\JARVIS\patches\JARVIS_v0.1.28_Orientation_Restore_Null_Fix.zip
3. Open Windows PowerShell 5.1 in F:\JARVIS\patches.
4. Run:

   New-Item -ItemType Directory -Force -Path '.\v0.1.28' | Out-Null
   Expand-Archive -LiteralPath '.\JARVIS_v0.1.28_Orientation_Restore_Null_Fix.zip' -DestinationPath '.\v0.1.28' -Force
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
   & '.\v0.1.28\Apply-JARVIS-v0.1.28.ps1'

Installer backs up App.tsx to F:\JARVIS\backups before replacing it.
No dependencies or models are changed.

Validation:
The patch is checked against the exact two no-reference branches responsible for leaking nullable orientation values. Re-run npm run build from F:\JARVIS\frontend after installation.
