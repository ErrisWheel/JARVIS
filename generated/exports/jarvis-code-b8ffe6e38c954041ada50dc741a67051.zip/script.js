const products = [
  { id: 1, name: "Wireless Headphones", price: 89.99, image: "https://via.placeholder.com/200x150" },
  { id: 2, name: "Smart Watch", price: 149.99, image: "https://via.placeholder.com/200x150" },
  { id: 3, name: "Bluetooth Speaker", price: 69.99, image: "https://via.placeholder.com/200x150" },
  { id: 4, name: "E-Reader", price: 129.99, image: "https://via.placeholder.com/200x150" },
  { id: 5, name: "Wireless Charger", price: 29.99, image: "https://via.placeholder.com/200x150" },
  { id: 6, name: "Smart Fitness Band", price: 49.99, image: "https://via.placeholder.com/200x150" },
  { id: 7, name: "Noise-Canceling Earbuds", price: 99.99, image: "https://via.placeholder.com/200x150" },
  { id: 8, name: "Smart Home Speaker", price: 119.99, image: "https://via.placeholder.com/200x150" },
  { id: 9, name: "Portable Power Bank", price: 39.99, image: "https://via.placeholder.com/200x150" },
  { id: 10, name: "Wireless Keyboard", price: 79.99, image: "https://via.placeholder.com/200x150" }
];

let cart = [];

function renderProducts() {
  const productsDiv = document.getElementById("products");
  productsDiv.innerHTML = "";

  products.forEach(product => {
    const card = document.createElement("div");
    card.className = "product-card";
    card.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <div class="card-body">
        <h5>${product.name}</h5>
        <div class="price">$${product.price.toFixed(2)}</div>
        <button onclick="addToCart(${product.id})">Add to Cart</button>
      </div>
    `;
    productsDiv.appendChild(card);
  });
}

function addToCart(productId) {
  const product = products.find(p => p.id === productId);
  cart.push(product);
  renderCart();
}

function renderCart() {
  const cartItemsDiv = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");
  const cartItems = [];

  cart.forEach((item, index) => {
    cartItems.push({
      id: item.id,
      name: item.name,
      price: item.price
    });
  });

  cartItemsDiv.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    const itemDiv = document.createElement("div");
    itemDiv.className = "cart-item";
    itemDiv.innerHTML = `
      <span>${item.name} - $${item.price.toFixed(2)}</span>
      <button onclick="removeFromCart(${index})">Remove</button>
    `;
    cartItemsDiv.appendChild(itemDiv);
    total += item.price;
  });

  cartTotal.textContent = `Total: $${total.toFixed(2)}`;
}

function removeFromCart(index) {
  cart.splice(index, 1);
  renderCart();
}

function checkout() {
  if (cart.length === 0) {
    alert("Your cart is empty. Nothing to checkout.");
    return;
  }

  const total = cart.reduce((sum, item) => sum + item.price, 0);
  const confirmation = confirm(`Your total is $${total.toFixed(2)}. Are you sure you want to checkout?`);

  if (confirmation) {
    alert("Thank you for your purchase! Your order is being processed.");
    cart = [];
    renderCart();
  }
}

// Initial render
renderProducts();
renderCart();
